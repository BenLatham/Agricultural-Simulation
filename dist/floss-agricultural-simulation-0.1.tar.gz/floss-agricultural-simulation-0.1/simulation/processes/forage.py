test = "---"


def monthly(year, month):
    print(test,"Forage is green in %2d/%d" %(month, year))