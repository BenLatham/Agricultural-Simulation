test = "---"


def monthly(year, month):
    print(test,"money gets spent in %2d/%d" %(month, year))


def capital(year):
    print(test,"at the end of %d we fix some stuff" % year)
