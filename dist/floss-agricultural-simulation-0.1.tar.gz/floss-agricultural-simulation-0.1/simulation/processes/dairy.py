test = "---"

def monthly(year, month):
    print (test,"cows go moo in %2d/%d" %(month, year))